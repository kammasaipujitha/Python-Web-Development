from django.db import models

# Create your models here.
from django.db import models

class Room(models.Model):
    room_number = models.CharField(max_length=10, unique=True)
    room_type = models.CharField(max_length=50)
    price_per_night = models.DecimalField(decimal_places=2, max_digits=10)
    is_available = models.BooleanField(default=True)

    def _str_(self):
        return self.room_number